package com.sathyatel.customerdetails.controller;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.customerdetails.entity.Customer;
import com.sathyatel.customerdetails.model.CustomerDTO;
import com.sathyatel.customerdetails.model.Login;
import com.sathyatel.customerdetails.model.PlanDTO;
import com.sathyatel.customerdetails.service.ICustomerService;

@RestController
@EnableDiscoveryClient
@RibbonClient(name = "custribbon")
public class CustomerRestController {
	
	/*
	 * private static String PLAN_URL =
	 * "http://localhost:5252/PlanDetailsApi/{planId}";
	 */
	/*
	 * private static String FRIEND_URL =
	 * "http://localhost:8000/FriendDetailsApi/friends/{phoneNo}";
	 */
	/*
	 * private static String FRIEND_URL =
	 * "http://custribbon/FriendDetailsApi/friends/{phoneNo}"; private static String
	 * ALLPLANS_URL="http://localhost:5252/PlanDetailsApi/allPlans";
	 */

	/*
	 * private static String PLAN_URL =
	 * "http://PLANDETAILSMS/PlanDetailsApi/{planId}"; private static String
	 * FRIEND_URL = "http://FRIENDDETAILSMS/FriendDetailsApi/friends/{phoneNo}";
	 * 
	 * private static String ALLPLANS_URL =
	 * "http://localhost:5252/PlanDetailsApi/allPlans";
	 */
	/*
	 * @Autowired RestTemplate restTemplate;
	 */

	@Autowired
	ICustomerService service;

	@Autowired
	CustomerCircuitService circuit;

	@PostMapping(value = "/register")
	public String registerCustomer(@RequestBody Customer customer) {
		String string = service.registerCustomer(customer);
		return string;
	}

	@PostMapping(value = "/login")
	public boolean loginCustomer(@RequestBody Login login) {

		return service.loginCustomer(login);

	}

	@GetMapping(value = "/profile/{phoneNo}", produces = "application/json")
	public CustomerDTO getProfile(@PathVariable Long phoneNo) {
		CustomerDTO customerDtoList = service.getProfile(phoneNo);

		
		/*
		 * PlanDTO planDto
		 * =restTemplate.getForObject(PLAN_URL,PlanDTO.class,customerDtoList.getPlanId()
		 * );
		 */
		  PlanDTO planDto  =  circuit.getPlanData(customerDtoList.getPlanId());
		Long x = System.currentTimeMillis();

		/*
		 * Future<PlanDTO> planDtofuture =
		 * circuit.getPlanData(customerDtoList.getPlanId()); try {
		 * customerDtoList.setPlaDto(planDtofuture.get()); } catch (Exception e) {
		 * 
		 * }
		 */
       
		Long y = System.currentTimeMillis();
		System.out.println("time taken in milles:" + (y - x));

		/*
		 * List<Long> friendsContactName = restTemplate.getForObject(FRIEND_URL,
		 * List.class, customerDtoList.getPhoneNo());
		 */
		List<Long> friendsContactName = circuit.getFriends(customerDtoList.getPhoneNo());

		 customerDtoList.setPlaDto(planDto); 
		customerDtoList.setFriendsContactNumbers(friendsContactName);

		System.out.println("***********101*************");
		return customerDtoList;
	}

	/*
	 * @GetMapping(value = "/plans") public String getAllPlans(@ModelAttribute Model
	 * model) { ParameterizedTypeReference<List<PlanDTO>> typeRef = new
	 * ParameterizedTypeReference<List<PlanDTO>>() {}; ResponseEntity<List<PlanDTO>>
	 * response = restTemplate.exchange(ALLPLANS_URL, HttpMethod.GET, null,
	 * typeRef); List<PlanDTO> plansList = response.getBody();
	 * model.addAttribute(plansList); return "plansList"; return null; }
	 */
}
