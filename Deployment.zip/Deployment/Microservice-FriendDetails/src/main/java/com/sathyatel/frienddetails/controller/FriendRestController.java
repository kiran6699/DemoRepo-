package com.sathyatel.frienddetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.frienddetails.entity.Friend;
import com.sathyatel.frienddetails.service.IFriendService;
@EnableDiscoveryClient
@RestController
public class FriendRestController {
	@Autowired
	IFriendService service;

	@PostMapping(value = "/addFriend", consumes = "application/json")
	public String addFriend(@RequestBody Friend friend) {
		return service.addFriendService(friend);
	}

	@GetMapping(value = "/friends/{phoneNo}", produces = "application/json")
	public List<Long> getAllFriends(@PathVariable Long phoneNo) {
		List<Long> friendsList = service.getFriendsContactService(phoneNo);
		return friendsList;

	}
}
