package com.sathyatel.frienddetails.service;

import java.util.List;

import com.sathyatel.frienddetails.entity.Friend;

public interface IFriendService {
	/*
	 * public String addFriend(Friend friend); public List<Long> getFriendList(Long
	 * phoneNo);
	 */
public String addFriendService(Friend friend);
public List <Long>getFriendsContactService(Long phoneNo);
}

